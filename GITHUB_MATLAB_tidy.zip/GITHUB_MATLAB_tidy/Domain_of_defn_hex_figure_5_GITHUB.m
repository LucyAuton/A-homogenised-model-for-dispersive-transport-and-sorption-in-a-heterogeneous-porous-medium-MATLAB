clear; 
clc; 
close all; 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Plots a vs phi for different R
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Construct a and phi from R<=R_crit
Rs1 = linspace(0.001,1/2/sqrt(3),100);
a_min1 = 2*Rs1;
phimins1 = 1-2*pi*Rs1.^2./a_min1; 

%Construct a and phi from R>R_crit
Rs2 = linspace(1/2/sqrt(3),1/2, 100);
a_min2 = sqrt(16*Rs2.^2-1);
phimins2 = 1-2*pi*Rs2.^2./a_min2; 

% Plot the left and lower bounding curves
figure(5);

semilogy(phimins1,a_min1,':k','Linewidth',2); 
hold on 
semilogy(phimins2,a_min2,'--k','Linewidth',2); 

% Calculate and plot (shaded grey) the attainable region of the phi a plane
Rs = [Rs1, Rs2];
amins = [a_min1, a_min2]; 
phimins = 1-2*pi*Rs.^2./amins; 
height = 100; 
amaxs = linspace(sqrt(3),height,2048); 
phiupper = 1-pi/4./amaxs;
R2 = 1/2;
as2 = linspace(sqrt(16*R2.^2-1),height,2048); 
phis2 = 1 - 2*pi*R2^2./as2; 

patch('xdata', [1,phimins,phiupper,1] , 'ydata', [amins(1),amins,amaxs,amaxs(end)],...
     'faceColor', [0.95 0.95 0.95], 'EdgeColor', 'none');
patch('xdata', [1,fliplr(phiupper), phis2 ,1] , 'ydata', [amins(1),fliplr(amaxs),as2, amaxs(end)],...
     'faceColor', [0.95 0.95 0.95], 'EdgeColor', 'none');

% Define vector of R values for which we plot
Rs_obs1 = [0.025, 0.075, 0.125, 0.175, 0.225, 1/2/sqrt(3)]; 
Rs_obs2 = [0.35,0.4, 0.45, 1/2 ];

%Define colour map
cc = parula(length(Rs_obs1)+length(Rs_obs2)+2); 

%Plot lines of constant R<=Rcrit
for iR = 1:length(Rs_obs1)

    R1 = Rs_obs1(iR);
    as1 = logspace(log10(2*R1),log10(height),2048); 
    phis1 = 1 - 2*pi*R1^2./as1; 
    
    semilogy(phis1,as1,'-','Linewidth',1,'color',cc(iR,:)); 
    % Add circles at the minimum value of phi for a given R 
    semilogy(phis1(1),as1(1),'o','color', cc(iR,:), 'MarkerFaceColor', cc(iR,:),'Markersize',3) 
end

%Plot lines of constant R>Rcrit
for iR = 1:length(Rs_obs2)

    R2 = Rs_obs2(iR);
    as2 = linspace(sqrt(16*R2.^2-1),height,2048); 
    phis2 = 1 - 2*pi*R2^2./as2; 
    
    semilogy(phis2,as2,'-','Linewidth',1,'color',cc(length(Rs_obs1)+iR,:)); 
    % Add circles at the minimum value of phi for a given R 
    semilogy(phis2(1),as2(1),'o','color', cc(length(Rs_obs1)+iR,:), 'MarkerFaceColor', cc(length(Rs_obs1)+iR,:),'Markersize',3) 
end

%Format and print figure
set(gca,'FontSize',10,'FontName','Times','LineWidth',1,'TickDir','in')
set(gca,'XMinorTick','off')
set(gca,'YMinorTick','on')
box on
set(gca,'linewidth',0.5)
set(gca,'layer','top')

xl = xlabel('$\hat{\phi}$');
xl.Interpreter = 'latex'; 
xl.FontSize = 10; 
yl = ylabel('$\hat{a}$');
yl.Interpreter = 'latex'; 
yl.FontName = 'Times'; 
yl.FontSize = 10; 

set(gca,'XTick',0:0.1:1.0)
set(gca,'XTickLabel',{'0','','0.2','','0.4','','0.6','','0.8','','1'})
ylim([1e-2 1e1])
xlim([0 1])

figw = 17.2; % cm
figh = .55*figw; 
set(gcf,'PaperUnits','centimeters')
set(gcf,'PaperSize',[figw figh])
set(gcf,'PaperPosition',[0 0 figw figh])
print(gcf,'-dpdf',strcat(['./Figures/','figure_5']));


