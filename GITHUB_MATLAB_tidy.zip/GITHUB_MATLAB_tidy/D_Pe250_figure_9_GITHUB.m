clear; 
clc; 
close all; 
format long

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   figure 9
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Import data 
DATA = importdata('Data/Data_Pe_250.txt');
DATA = DATA.data;
Rs = DATA(:,1);
ass = DATA(:,2);
K11s_over_phi= DATA(:,3);
K22s_over_phi = DATA(:,4);
Dobst11s = DATA(:,5);
Dobst22s = DATA(:,6);
Ddisp11s = DATA(:,7);
Ddisp22s = DATA(:,8);

% Separate data for each R
[b, c, d] = unique(Rs,'stable');

for i = 1:d(end)
    
    R = b(i); 
    if i == d(end) 
        as = ass(c(i):length(ass));

        K11_over_phi = K11s_over_phi(c(i):length(ass));
        K22_over_phi = K22s_over_phi(c(i):length(ass));
        
        Dobst11 = Dobst11s(c(i):length(ass));
        Dobst22 = Dobst22s(c(i):length(ass));
        
        Ddisp11 = Ddisp11s(c(i):length(ass));
        Ddisp22 = Ddisp22s(c(i):length(ass));
    else 
        as = ass(c(i):(c(i+1)-1));

        K11_over_phi = K11s_over_phi(c(i):(c(i+1)-1));
        K22_over_phi = K22s_over_phi(c(i):(c(i+1)-1));
    
        Dobst11 = Dobst11s(c(i):(c(i+1)-1));
        Dobst22 = Dobst22s(c(i):(c(i+1)-1));
        
        Ddisp11 = Ddisp11s(c(i):(c(i+1)-1));
        Ddisp22 = Ddisp22s(c(i):(c(i+1)-1));    
    end 
    
    %Interpolation parameter
    m=10;

    %Construct quantities 
    Dhat11 = ones(length(as),1)- Dobst11+Ddisp11;
    Dhat22 = ones(length(as),1)- Dobst22+Ddisp22;
    phi = 1-2*pi*R^2./as;

    %Interpolation
    phiINTERP = interp(phi,m); 
    K11INTERP = interp(phi.*K11_over_phi,m);
    K22INTERP = interp(phi.*K22_over_phi,m);
    Dobst11INTERP = interp(Dobst11,10);
    Dobst22INTERP = interp(Dobst22,10);
    Ddisp11INTERP = interp(Ddisp11,10);
    Ddisp22INTERP = interp(Ddisp22,10);
    Dhat11INTERP = interp(Dhat11,m);
    Dhat22INTERP = interp(Dhat22,m);
    
    %Ploting parameter (marker size)
    MS =12; 
   
    % Set up colours 
    cc = parula(length(b)+1); 

    %Refine interpolation and plot
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    figure(9)
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    subplot(3,2,1)
    if i==5
        phiINTERP_223_5 = interp([0.10507; phi(1:2); phi(4:5); phi(7); phi(9:14); phi(16:17); phi(20); phi(end)],m);
        Dhat11INTERP_223_5 = interp([0; Dhat11(1:2);Dhat11(4:5); Dhat11(7); Dhat11(9:14); Dhat11(16:17); Dhat11(20); Dhat11(end)] ,m);
        plot([0.10507, 0.10507] ,[0 .3],'-','Linewidth',1,'color',[1 0 0]);
        semilogy(phiINTERP_223_5(10:41), Dhat11INTERP_223_5(10:41),'-','Linewidth',1,'color',cc(i,:));
        semilogy(phiINTERP_223_5(121:end), Dhat11INTERP_223_5(121:end),'-','Linewidth',1,'color',cc(i,:));
        semilogy(phi(5:16), Dhat11(5:16),'-','Linewidth',1,'color',cc(i,:));
        semilogy([0.105066; phi(1)], [0; Dhat11(1)],':','Linewidth',1,'color',[1 0 0]);
    elseif i==4 
        phi_223_4 = interp([0.1951; phi(1:2); phi(4:end)],m);
        Dhat11_223_4 = interp([0; Dhat11(1:2); Dhat11(4:end)],m);
        plot([0.1951, 0.1951] ,[0 .3],'-','Linewidth',1,'color',[1 0 0]);
        plot(phi_223_4(10:end),Dhat11_223_4(10:end),'-','Linewidth',1,'color',cc(i,:)); 
        plot([0.1951; phi(1)],[0; Dhat11(1)],':','Linewidth',1,'color',[1 0 0]); 
    elseif i ==3 
        phiINTERP_223_3 = interp([0.0931; phi],m); 
        Dhat11INTERP_223_3 = interp([0; Dhat11],m);
        plot([0.0931, 0.0931] ,[0 .3],'-','Linewidth',1,'color',[1 0 0]);
        plot(phiINTERP_223_3(10:end),Dhat11INTERP_223_3(10:end),'-','Linewidth',1,'color',cc(i,:)); 
        plot(phiINTERP_223_3(1:10),Dhat11INTERP_223_3(1:10),':','Linewidth',1,'color',[1 0 0]); 
    elseif i ==2 
        plot(phiINTERP,Dhat11INTERP,'-','Linewidth',1,'color',cc(i,:)); 
        scatter(phiINTERP(1), Dhat11INTERP(1), MS, 'o','MarkerEdgeColor',cc(i,:),...
        'MarkerFaceColor', cc(i,:)); 
    elseif i ==1 
        plot(phiINTERP,Dhat11INTERP,'-','Linewidth',1,'color',cc(i,:)); 
        hold on
        scatter(phiINTERP(1), Dhat11INTERP(1), MS, 'o','MarkerEdgeColor',cc(i,:),...
        'MarkerFaceColor', cc(i,:)); 
    end 
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    subplot(3,2,2)
    if i==5
        phi_224_5 = interp([phi(1:2); phi(4:17); phi(19:end-2); phi(end)],10);
        Dhat22_224_5 = interp([Dhat22(1:2); Dhat22(4:17); Dhat22(19:end-2); Dhat22(end)],10);
        phis_224_5 = [phi_224_5(1:31); phi(5:16); phi_224_5(142:151); phi(18:end)];
        Dhat22s_224_5 = [Dhat22_224_5(1:31); Dhat22(5:16); Dhat22_224_5(142:151);Dhat22(18:end)];

        plot([0.105066, 0.105066] ,[0 .3],'-','Linewidth',1,'color',[1 0 0]);
        plot(phis_224_5, Dhat22s_224_5,'-','Linewidth',1,'color',cc(i,:)); 
        semilogy([0.105066; phi(1)], [0; Dhat22(1)],':','Linewidth',1,'color',[1 0 0]);
    elseif i==4 
        phiINTERP2 = interp([0.1951; phi(1:9)],m);
        Dhat22INTERP2 = interp([0; Dhat22(1:9)],m);
        phi_extra_224_4 = phiINTERP2(1:10); 
        Dhat22_extra_224_4 = Dhat22INTERP2(1:10); 
        phiINTERP2 = phiINTERP2(10:23);
        Dhat22INTERP2 = Dhat22INTERP2(10:23);
        phiINTERP4 = phi(3:end); 
        Dhat22INTERP4 = Dhat22(3:end); 
        phiINTERP_224_4 = [phiINTERP2; phiINTERP4];
        Dhat22INTERP_224_4 = [Dhat22INTERP2;  Dhat22INTERP4];

        plot([0.1951, 0.1951] ,[0 .3],'-','Linewidth',1,'color',[1 0 0]);
        plot(phiINTERP_224_4,Dhat22INTERP_224_4,'-','Linewidth',1,'color',cc(i,:));
        plot([0.1951; phi(1)] ,[0; Dhat22(1)],':','Linewidth',1,'color',[1 0 0]);
   elseif i ==3 
        phiINTERP_224_3 = interp([0.0931; phi],m);
        Dhat22INTERP_224_3 = interp([0; Dhat22],m);
        plot([0.0931, 0.0931] ,[0 .3],'-','Linewidth',1,'color',[1 0 0]);
        plot(phiINTERP_224_3(10:end),Dhat22INTERP_224_3(10:end),'-','Linewidth',1,'color',cc(i,:));
        plot(phiINTERP_224_3(1:10),Dhat22INTERP_224_3(1:10),':','Linewidth',1,'color',[1 0 0]);
    elseif i ==2 
        phiINTERP_224_2 = interp([0.37168; phi],m); 
        Dhat22INTERP_224_2 = interp([0; Dhat22],m);
        plot([0.37168, 0.37168] ,[0 .3],'-','Linewidth',1,'color',[1 0 0]);
        plot(phiINTERP_224_2(10:end),Dhat22INTERP_224_2(10:end),'-','Linewidth',1,'color',cc(i,:));
        plot(phiINTERP_224_2(1:10),Dhat22INTERP_224_2(1:10),':','Linewidth',1,'color',[1 0 0]);
    elseif i==1 
        phiINTERP_224_1 = interp([0.68584; phi],m); 
        Dhat22INTERP_224_1 = interp([0; Dhat22],m);
        plot([0.68584, 0.68584] ,[0 .3],'-','Linewidth',1,'color',[1 0 0]);
        hold on
        plot(phiINTERP_224_1(10:end),Dhat22INTERP_224_1(10:end),'-','Linewidth',1,'color',cc(i,:));
        plot(phiINTERP_224_1(1:10),Dhat22INTERP_224_1(1:10),':','Linewidth',1,'color',[1 0 0]);
    end 

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    subplot(3,2,3)
    if i ==1 
        plot(phiINTERP, Dobst11INTERP,'-','Linewidth',1,'color',cc(i,:)); 
        hold on
        scatter(phiINTERP(1), Dobst11INTERP(1), MS, 'o','MarkerEdgeColor',cc(i,:),...
        'MarkerFaceColor', cc(i,:)); 
    elseif i ==2 
        plot(phiINTERP, Dobst11INTERP,'-','Linewidth',1,'color',cc(i,:)); 
        scatter(phiINTERP(1), Dobst11INTERP(1), MS, 'o','MarkerEdgeColor',cc(i,:),...
        'MarkerFaceColor', cc(i,:)); 
    elseif i == 3 
        phiINTERP_223_3 = interp([0.0931; phi(1:2); phi(4); phi(6); phi(9:end)],m);
        Dobst11INTERP_223_3 = interp([1; Dobst11(1:2); Dobst11(4); Dobst11(6); Dobst11(9:end)] ,m);
        plot([0.0931, 0.0931] ,[.7 1],'-','Linewidth',1,'color',[1 0 0]);
        plot(phiINTERP_223_3(1:10), Dobst11INTERP_223_3(1:10),':','Linewidth',1,'color',[1 0 0]); 
        plot(phiINTERP_223_3(10:end), Dobst11INTERP_223_3(10:end),'-','Linewidth',1,'color',cc(i,:)); 
    elseif i==4 
        phiINTERP_223_4 = interp([0.1951; phi(1:2); phi(4); phi(6:end)],m);
        Dobst11INTERP_223_4 = interp([1; Dobst11(1:2); Dobst11(4); Dobst11(6:end)] ,m);
        plot([0.1951, 0.1951] ,[.7 1],'-','Linewidth',1,'color',[1 0 0]);
        plot([phiINTERP_223_4(1) phiINTERP_223_4(10)],[Dobst11INTERP_223_4(1),Dobst11INTERP_223_4(10)],':','Linewidth',1,'color',[1 0 0]);
        plot(phiINTERP_223_4(10:end),Dobst11INTERP_223_4(10:end),'-','Linewidth',1,'color',cc(i,:));
    elseif i==5
        phiINTERP_223_5 = interp([0.10507; phi(1:2); phi(4:6); phi(16:17); phi(21:22)],m);
        Dobst11INTERP_223_5 = interp([1; Dobst11(1:2);Dobst11(4:6); Dobst11(16:17); Dobst11(21:22)] ,m);
        plot([0.105066, 0.105066] ,[.7 1],'-','Linewidth',1,'color',[1 0 0]);
        plot([phiINTERP_223_5(1) phiINTERP_223_5(10)], [Dobst11INTERP_223_5(1) Dobst11INTERP_223_5(10)],':','Linewidth',1,'color',[1 0 0]);
        plot(phiINTERP_223_5(10:end), Dobst11INTERP_223_5(10:end),'-','Linewidth',1,'color',cc(i,:));
    end 

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    subplot(3,2,4)
    if i ==1 
        phiINTERP_222_1 = interp([0.68584; phi],10);
        Dobst22INTERP_222_1 = interp([1; Dobst22],10);
        plot([0.68584, 0.68584] ,[.7 1],'-','Linewidth',1,'color',[1 0 0]);
        hold on
        plot(phiINTERP_222_1(10:end),Dobst22INTERP_222_1(10:end),'-','Linewidth',1,'color',cc(i,:)); 
        plot(phiINTERP_222_1(1:10),Dobst22INTERP_222_1(1:10),':','Linewidth',1,'color',[1 0 0]);
        plot([0.68584, 0.68584] ,[.7 1],'-','Linewidth',1,'color',[1 0 0]);
    elseif i == 2 
        phiINTERP_222_2 = interp([0.37168; phi],10);
        Dobst22INTERP_222_2 = interp([1; Dobst22],10);
        plot([0.37168, 0.37168] ,[.7 1],'-','Linewidth',1,'color',[1 0 0]);
        plot(phiINTERP_222_2(10:end),Dobst22INTERP_222_2(10:end),'-','Linewidth',1,'color',cc(i,:)); 
        plot(phiINTERP_222_2(1:10),Dobst22INTERP_222_2(1:10),':','Linewidth',1,'color',[1 0 0]);
    elseif i == 3
        phiINTERP_224_3 = interp([0.0931; phi(1:2); phi(4); phi(6); phi(9:end)],m);
        Dobst22INTERP_224_3 = interp([1; Dobst22(1:2); Dobst22(4); Dobst22(6); Dobst22(9:end)] ,m);
        plot([0.0931, 0.0931] ,[.7 1],'-','Linewidth',1,'color',[1 0 0]);
        plot(phiINTERP_224_3(10:end),Dobst22INTERP_224_3(10:end),'-','Linewidth',1,'color',cc(i,:));
        plot(phiINTERP_224_3(1:10),Dobst22INTERP_224_3(1:10),':','Linewidth',1,'color',[1 0 0]);
    elseif i ==4 
        phiINTERP_224_4 = interp([0.1951; phi(1:2); phi(5:end)],m);
        Dobst22INTERP_224_4 = interp([1; Dobst22(1:2);Dobst22(5:end)] ,m);
        plot([0.1951, 0.1951] ,[.7 1],'-','Linewidth',1,'color',[1 0 0]);
        plot(phiINTERP_224_4(10:end),Dobst22INTERP_224_4(10:end),'-','Linewidth',1,'color',cc(i,:));
        plot(phiINTERP_224_4(1:10),Dobst22INTERP_224_4(1:10),':','Linewidth',1,'color',[1 0 0]);
    elseif i==5
        phiINTERP_224_5 = interp([phi(1:2); phi(4:5); phi(11); phi(16:end)],m);
        Dobst22INTERP_224_5 = interp([Dobst22(1:2);Dobst22(4:5); Dobst22(11); Dobst22(16:end)] ,m);
        plot([0.105066, 0.105066] ,[.7 1],'-','Linewidth',1,'color',[1 0 0]);
        plot(phiINTERP_224_5,Dobst22INTERP_224_5,'-','Linewidth',1,'color',cc(i,:));
        plot([0.105066 phiINTERP_224_5(1)], [1 Dobst22INTERP_224_5(1)],':','Linewidth',1,'color',[1 0 0]);
    else
        plot(phiINTERP,Dobst22INTERP,'-','Linewidth',1,'color',cc(i,:)); 
    end 

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    subplot(3,2,5)
    if i ==1 
        semilogy(phiINTERP, Dobst11INTERP,'-','Linewidth',1,'color',cc(i,:)); 
        hold on
        scatter(phiINTERP(1), Dobst11INTERP(1), MS, 'o','MarkerEdgeColor',cc(i,:),...
        'MarkerFaceColor', cc(i,:));
    elseif i ==2 
        phiINTERP_223_2 = interp([phi(1:16); phi(21:end)],10);
        Ddisp11INTERP_223_2 = interp([Ddisp11(1:16); Ddisp11(21:end)],10);
        semilogy([phi(1:17); phi(19:21)], [Ddisp11(1:17); Ddisp11(19:21)],'-','Linewidth',1,'color',cc(i,:)); 
        semilogy(phiINTERP_223_2(160:end), Ddisp11INTERP_223_2(160:end),'-','Linewidth',1,'color',cc(i,:)); 
        scatter(phiINTERP_223_2(1), Ddisp11INTERP_223_2(1), MS, 'o','MarkerEdgeColor',cc(i,:),...
        'MarkerFaceColor', cc(i,:)); 
    elseif i == 3  
        phiINTERP_223_3 = interp([phi(9:end)],10); 
        Ddisp11INTERP_223_3 = interp([Ddisp11(9:end)],10);
        N = 100; 
        phi_test = linspace(0.0931,phi(9),N);
        Ddisp11_test = interp1([0.0931; phi(1:7); phi(9:12)], [1e-16; Ddisp11(1:7); Ddisp11(9:12)], linspace(0.0932,phi(9),N), 'pchip'); 
        semilogy(phi_test(12:end), Ddisp11_test(12:end),'-','Linewidth',1,'color',cc(i,:));
        semilogy([0.0931, 0.0931] ,[1e-14 1e-9],'-','Linewidth',1,'color',[1 0 0]);
        semilogy(phi(1:2), Ddisp11(1:2),'-','Linewidth',1,'color',cc(1,:));
        semilogy(phiINTERP_223_3, Ddisp11INTERP_223_3,'-','Linewidth',1,'color',cc(i,:));
        semilogy(phi_test(1:4) ,[Ddisp11_test(1:4)],':','Linewidth',1,'color',[1 0 0]);
    elseif i==4 
        phiINTERP_223_4 = logspace(log10(0.1951), log10(phi(end)),2000);
        Ddisp11INTERP_223_4 = interp1([0.1951; phi(1:end)],[0;  Ddisp11(1:end)] ,phiINTERP_223_4, 'pchip');
        plot([0.1951, 0.1951] ,[1e-14 1e-9],'-','Linewidth',1,'color',[1 0 0]);
        semilogy(phiINTERP_223_4(1:25), Ddisp11INTERP_223_4(1:25),':','Linewidth',1,'color',[1 0 0]);
        semilogy([phiINTERP_223_4(25:257) phiINTERP_223_4(759:end)],[Ddisp11INTERP_223_4(25:257) Ddisp11INTERP_223_4(759:end)] ,'-','Linewidth',1,'color',cc(i,:));
    elseif i==5
        phiINTERP_223_5 = interp([0.10507; phi(1:2); phi(4); phi(7:end)],m);
        phi_small_233_5 = phiINTERP_223_5(1:55); 
        Ddisp11INTERP_223_5 = interp([0; Ddisp11(1:2);Ddisp11(4); Ddisp11(7:end)] ,m);
        plot([0.10507, 0.10507] ,[1e-14 1e-9],'-','Linewidth',1,'color',[1 0 0]);
        semilogy(phi_small_233_5(11:end), Ddisp11INTERP_223_5(11:55),'-','Linewidth',1,'color',cc(i,:));
        semilogy(phi(9:end), Ddisp11(9:end),'-','Linewidth',1,'color',cc(i,:));
    end 

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    subplot(3,2,6)
    if i ==1 
        phiINTERP_224_1 = interp([0.68584; phi],10);
        Ddisp22INTERP_222_1 = interp([0; Ddisp22],10);
        plot(phiINTERP_222_1(10:end),Ddisp22INTERP_222_1(10:end),'-','Linewidth',1,'color',cc(i,:)); 
        hold on
        plot(phiINTERP_222_1(1:10),Ddisp22INTERP_222_1(1:10),':','Linewidth',1,'color',[1 0 0]);
    elseif i == 2 
        phiINTERP_222_2 = interp([0.37168; phi],10);
        Ddisp22INTERP_222_2 = interp([0; Ddisp22],10);
        plot(phiINTERP_222_2(10:end),Ddisp22INTERP_222_2(10:end),'-','Linewidth',1,'color',cc(i,:)); 
        plot(phiINTERP_222_2(1:10),Ddisp22INTERP_222_2(1:10),':','Linewidth',1,'color',[1 0 0]);
    elseif i == 3
        phiINTERP_224_3 = interp([0.0931; phi(1:2); phi(4); phi(6:end)],m);
        Ddisp22INTERP_224_3 = interp([0; Ddisp22(1:2); Ddisp22(4); Ddisp22(6:end)] ,m);
        plot(phiINTERP_224_3(10:end),Ddisp22INTERP_224_3(10:end),'-','Linewidth',1,'color',cc(i,:));
        plot(phiINTERP_224_3(1:10),Ddisp22INTERP_224_3(1:10),':','Linewidth',1,'color',[1 0 0]);
    elseif i ==4 
        phiINTERP_224_4 = interp([0.1951; phi(1:2); phi(5:end)],m);
        Ddisp22INTERP_224_4 = interp([0; Ddisp22(1:2);Ddisp22(5:end)] ,m);
        plot(phiINTERP_224_4(10:end),Ddisp22INTERP_224_4(10:end),'-','Linewidth',1,'color',cc(i,:));
        plot(phiINTERP_224_4(1:10),Ddisp22INTERP_224_4(1:10),':','Linewidth',1,'color',[1 0 0]);
    elseif i==5
        phiINTERP_224_5 = interp([phi(1:2); phi(4:end)],m);
        Ddisp22INTERP_224_5 = interp([Ddisp22(1:2);Ddisp22(4:end)] ,m);
        plot(phiINTERP_224_5,Ddisp22INTERP_224_5,'-','Linewidth',1,'color',cc(i,:));
        hold on
        plot([0.105066 phiINTERP_224_5(1)], [0 Ddisp22INTERP_224_5(1)],':','Linewidth',1,'color',[1 0 0]);
    end 
end

%Font size
FS = 10; 

%Format and print Figures
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(9)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figw = 17.2; % cm
subfigw = 0.40; % Fraction of figw
subfigh = 0.25; % Fraction of figh
padleft = 1.75/figw; % Fraction of figw
padbottom = 1.5/figw; % Fraction of figw
padbetween = 1.15/figw; % Fraction of figw
figh = .75*figw; 

for i=1:2
    subplot(3,2,1+(i-1))
    box on
    set(gca,'Linewidth',1)
    set(gca,'layer','top')
    set(gca,'FontSize',FS,'FontName','Times New Roman')
    if i==1
        ylabel('$\hat{\left({\mathrm{\textit{\textbf{D}}}}\right)}_{11}$','Interpreter','latex')
        set(gca,'YLim',[0,2])
    elseif i==2
        ylabel('$\hat{\left({\mathrm{\textit{\textbf{D}}}}\right)}_{22}$','Interpreter','latex')
        set(gca,'YLim',[0,1.2])
        set(gca,'YTick',0:0.2:1.2)
        set(gca,'YTickLabel',{'0','','0.4','','0.8','','1.2'})
    end
    set(gca,'XLim',[0,1])
    set(gca,'XTick',0:0.2:1)
    set(gca,'XTickLabel',{'0','0.2','0.4','0.6','0.8','1'})

    subplot(3,2,3+(i-1))
    box on
    set(gca,'Linewidth',1)
    set(gca,'layer','bottom')
    set(gca,'FontSize',FS,'FontName','Times New Roman')
    if i==1
        ylabel('$\left(\hat{{\mathrm{\textit{\textbf{D}}}}}_\mathrm{obst}\right)_{11}$','Interpreter','latex')
    elseif i==2
        ylabel('$\left(\hat{\mathrm{\textit{\textbf{D}}}}_\mathrm{obst}\right)_{22}$','Interpreter','latex')
    end
    set(gca,'YLim',[0,1])
    set(gca,'XLim',[0,1])
    set(gca,'XTick',0:0.2:1)
    set(gca,'XTickLabel',{'0','0.2','0.4','0.6','0.8','1'})
    set(gca,'YminorTick','off')

    subplot(3,2,5+(i-1))
    box on
    set(gca,'Linewidth',1)
    set(gca,'layer','bottom')
    set(gca,'FontSize',FS,'FontName','Times New Roman')
    xlabel('$\hat{\phi}(x_1)$','Interpreter','latex')
    if i==1
        ylabel('$\left(\hat{{\mathrm{\textit{\textbf{D}}}}}_\mathrm{disp}\right)_{11}$','Interpreter','latex')
        set(gca,'YLim',[1e-13 2])
        set(gca,'YTick',[1e-12, 1e-10, 1e-8, 1e-6, 1e-4, 1e-2, 1e0])
        set(gca,'YTickLabel',{'10^{-12}','','10^{-8}','','10^{-4}','', '10^0'})
        set(gca,'YminorTick','off')
    elseif i==2
        ylabel('$\left(\hat{{\mathrm{\textit{\textbf{D}}}}}_\mathrm{disp}\right)_{22}$','Interpreter','latex')
        set(gca,'YLim',[0 .001])
    end
    set(gca,'XLim',[0,1])
    set(gca,'XTick',0:0.2:1)
    set(gca,'XTickLabel',{'0','0.2','0.4','0.6','0.8','1'})     
end

subplot(3,2,1)
set(gca,'Position',[padleft,padbottom+2*(subfigh+padbetween),subfigw,subfigh])
subplot(3,2,2)
set(gca,'Position',[padleft+(subfigw+1.4*padbetween),padbottom+2*(subfigh+padbetween),subfigw,subfigh])

subplot(3,2,3)
set(gca,'Position',[padleft,padbottom+(subfigh+padbetween),subfigw,subfigh])
subplot(3,2,4)
set(gca,'Position',[padleft+(subfigw+1.4*padbetween),padbottom+(subfigh+padbetween),subfigw,subfigh])

subplot(3,2,5)
set(gca,'Position',[padleft,padbottom,subfigw,subfigh])
subplot(3,2,6)
set(gca,'Position',[padleft+(subfigw+1.4*padbetween),padbottom,subfigw,subfigh])

set(gcf,'PaperUnits','centimeters')
set(gcf,'PaperSize',[figw figh])
set(gcf,'PaperPosition',[0 0 figw figh])
print(gcf,'-dpdf','Figures/figure_9.pdf');