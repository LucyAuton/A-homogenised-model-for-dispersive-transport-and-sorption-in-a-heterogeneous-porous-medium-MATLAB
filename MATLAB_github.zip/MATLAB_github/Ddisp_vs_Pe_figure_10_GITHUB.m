clear all; 
close all; 
clc; 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Plots Ddisp_ii vs Pe 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Define parameters
R = 1/2/sqrt(3);
a = 1; 
phi = 1-2*pi*R.^2./a;

%Import data: 11 component 
K11ss_over_phi = importdata('Data/K11_over_phi_R_eq_thresh_a_1_varying_Pe.txt');
%Import vector of Pe
Pes = K11ss_over_phi.data(:,1);
Ddisp11ss = importdata('Data/D_disp_11_R_eq_thresh_a_1_varying_Pe.txt');
Ddisp11s= Ddisp11ss.data(:,2);

%Import data: 22 component 
Ddisp22ss = importdata('Data/D_disp_22_R_eq_thresh_a_1_varying_Pe.txt');
Ddisp22s= Ddisp22ss.data(:,2);

%Set font size
FS = 10; 
figure(10)

%Plot Ddisp_ii vs Pe: linear 
subplot(121)
plot(Pes, Ddisp11s, '--','Linewidth',1, 'Color', [232, 135, 14]/255)
hold on 
plot(Pes, Ddisp22s, '-','Linewidth',1, 'Color', [73, 236, 196]/255)
legend('$\left(\hat{\textbf{\textit{D}}}_\mathrm{disp}\right)_{11}$',...
'$\left(\hat{\textbf{\textit{D}}}_\mathrm{disp}\right)_{22}$',...
'Interpreter','latex', 'FontSize',FS, 'location', 'northwest') 

%Plot Ddisp_ii vs Pe: log
subplot(122)
loglog([5 5],[1e-6 1e-4], '-','Linewidth',1,'Color', [0, 0, 0]/255)
hold on 
loglog([5 50],[1e-4 1e-4], '-','Linewidth',1,'Color', [0, 0, 0]/255)
loglog(Pes, Ddisp22s, '-','Linewidth',1, 'Color', [73, 236, 196]/255)
loglog(Pes, Ddisp11s, '--','Linewidth',1, 'Color', [232, 135, 14]/255)
xlim([1 500])
ylim([1e-9, 1e-2])

% Format Figure
figw = 17.2; % cm
subfigw = 0.38; % Fraction of figw
subfigh = 0.75; % Fraction of figh
padleft = 1.7/figw; % Fraction of figw
padbottom = 3/figw; % Fraction of figw
padbetween = 0.9/figw; % Fraction of figw
figh = figw/(2.7); 

for i=1:2
    subplot(1,2,i)
    box on
    set(gca,'FontSize',FS,'FontName','Times New Roman','Linewidth',1)
    if i ==1 
        xlabel('$\mathrm{Pe}_l$','Interpreter','latex')
        ylabel('$\left(\hat{\textbf{\textit{D}}}_\mathrm{disp}\right)_{ii}$','Interpreter','latex') 
    elseif i ==2  
        xlabel('$\mathrm{Pe}_l$','Interpreter','latex')
        grid on
        set(gca, 'YMinorTick','off', 'YMinorGrid','off')
        set(gca,'YTick',[1e-9, 1e-8, 1e-7, 1e-6, 1e-5, 1e-4, 1e-3, 1e-2])
        set(gca,'YTickLabel',{'','10^{-8}','','10^{-6}','','10^{-4}','','10^{-2}'})
    end 
end

subplot(1,2,1)
set(gca,'Position',[padleft,padbottom,subfigw,subfigh])
box on 
subplot(1,2,2)
set(gca,'Position',[padleft+(subfigw+2*padbetween),padbottom,subfigw,subfigh])
box on 

set(gcf,'PaperUnits','centimeters')
set(gcf,'PaperSize',[figw figh])
set(gcf,'PaperPosition',[0 0 figw figh])
print(gcf,'-dpdf','Figures/figure_10.pdf');
