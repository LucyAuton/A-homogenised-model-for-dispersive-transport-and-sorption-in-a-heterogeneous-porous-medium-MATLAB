clear; 
clc; 
close all; 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Plots F vs phi
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fig1 = figure(6);

N=1000;

%Construct large vector of R, for R <= and > Rcrit
Rsmin1 = linspace(1E-8,1/2/sqrt(3),N);
Rsmin2 = linspace(1/2/sqrt(3), 0.5-1e-8,N);
% Define vector of R values for which we plot
Rs = [0.1 ; 0.2; 1/2/sqrt(3); 0.4; 0.49];
%Define vector of phi values for which we plot
phis = [0.15 0.2 0.3 0.45 0.6 0.75 0.85 0.95];

%Find bounds for region of attainability: 
%Upper bound 
asmin1 = 2*Rsmin1;
phis_min1 = 1 - pi*asmin1/2;  
Fs_min1 = 2*pi./phis_min1;  

%Left-hand bound 
asmin2 = sqrt(16*Rsmin2.^2-1); 
phis_min2 = 1 - pi*(asmin2.^2+1)/8./asmin2; 
Fs_min2 = 4*pi*Rsmin2./asmin2./phis_min2; 

%Lower bound: R=1/2
asmin3 = linspace(sqrt(3),1000, 10000);
phis_min3 = 1-pi/2./asmin3;
Fs_min3 = 2*pi./asmin3./phis_min3; 
Rsmin3 = ones(size(Fs_min3))/2;

%Define colour maps
cc = parula(length(Rs)+1);
cc1 = pink(length(phis)+7);

subfig1 = subplot(121);

%Plot the bounds
plot(phis_min2,Fs_min2,'--k','Linewidth',1); 
hold on 
plot(phis_min1,Fs_min1,':k','Linewidth',1.5); 
plot(phis_min3,Fs_min3,'-','Linewidth',1,'color', cc(end,:)); 

%Shades attainable region of phi F plane
patch('xdata', [1,phis_min2 ,phis_min3,phis_min1] , 'ydata', [Fs_min2(1),Fs_min2,Fs_min3 ,Fs_min1],...
     'faceColor', [0.95 0.95 0.95], 'EdgeColor', 'none');

%Plot F vs phi for constant R
for iR = 1:length(Rs)

    R = Rs(iR);
    if R> 1/2/sqrt(3)
        as = logspace(log10(sqrt(16*R^2-1)),2,1000);
    else 
        as = logspace(log10(2*R),2,1000);
    end 
    phis2 = 1 - 2*pi*(R^2)./as;
    Fs = 4*pi*R./(as.*phis2);
    
    plot(phis2,Fs,'-','Linewidth',1,'color',cc(iR,:));
    hold on
    plot(phis2(1),Fs(1),'o','color', cc(iR,:), 'MarkerFaceColor', ...
    cc(iR,:),'Markersize',3)
end

%Format subfigure
box on
set(gca,'FontSize',10,'FontName','Times','Linewidth',1)
set(gca,'XMinorTick','off');
set(gca,'YMinorTick','off');
xlim([0,1])
xlabel('$\hat{\phi}$','Interpreter','latex');
ylabel('$\displaystyle\frac{\hat{F}(\hat{\phi},\hat{a})}{\gamma}$','Interpreter','latex');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Plot F vs R 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

subfig2 = subplot(122);

%Plot the bounds
plot(Rsmin1,Fs_min1,':k','Linewidth',1.5); 
hold on
plot(Rsmin2,Fs_min2,'--k','Linewidth',1); 
plot(Rsmin3,Fs_min3,'-','Linewidth',1,'color', cc(end,:));

%Shades attainable region of phi F plane
 patch('xdata', [0,Rsmin1 ,Rsmin2, 1/2] , 'ydata', [0,Fs_min1,Fs_min2 ,Fs_min3(end)],...
     'faceColor', [0.95 0.95 0.95], 'EdgeColor', 'none');

 %Plot F vs R for constant phi
 for iphi = 1:length(phis)
    Rs1 = linspace(1E-3,1/2 ,N);
    phi = phis(iphi);
    
    as1 = 2*pi*(Rs1.^2)/(1-phi);
    Fs1 = 4*pi*Rs1./(as1*phi);
    
    if phi<0.25
        ikeep = as1>(2*Rs1); 
        Rs1 = Rs1(ikeep);
        Fs1 = Fs1(ikeep);
        as1 = as1(ikeep);
        icut = as1<sqrt(16*Rs1.^2-1);
        
        index = find(icut, 1 )-1; 
        
        as11 = as1(1:index);
        Rs11 = Rs1(1:index);
        Fs11 = Fs1(1:index);
        
        index2 = find(icut, 1, 'last' )+1;
        
        as12 = as1(index2:end);
        Rs12 = Rs1(index2:end);
        Fs12 = Fs1(index2:end);
        
        semilogy(Rs11,Fs11,'Linewidth',1,'Color',cc1(iphi,:))
        semilogy(Rs12,Fs12,'Linewidth',1,'Color',cc1(iphi,:))
        plot(Rs11(1),Fs11(1),'o','color', cc1(iphi,:), 'MarkerFaceColor', ...
        cc1(iphi,:),'Markersize',3)
        plot(Rs11(end),Fs11(end),'o','color', cc1(iphi,:), 'MarkerFaceColor', ...
        cc1(iphi,:),'Markersize',3)
        plot(Rs12(1),Fs12(1),'o','color', cc1(iphi,:), 'MarkerFaceColor', ...
        cc1(iphi,:),'Markersize',3)
    else 
        ikeep2 = as1>(2*Rs1); 
        Rs1 = Rs1(ikeep2);
        Fs1 = Fs1(ikeep2);
        as1 = as1(ikeep2);
        semilogy(Rs1,Fs1,'Linewidth',1,'Color',cc1(iphi,:))
        plot(Rs1(1),Fs1(1),'o','color', cc1(iphi,:), 'MarkerFaceColor', ...
        cc1(iphi,:),'Markersize',3)
    end
 end

%Format subfigure
box on
set(gca,'FontSize',10,'FontName','Times','Linewidth',1)
set(gca,'XMinorTick','off');
set(gca,'YMinorTick','off');

xlim([0,0.5])
set(gca,'XTick',0.0:0.05:0.5)
set(gca,'XTickLabel',{'0','','0.1','','0.2','','0.3','','0.4','','0.5'})
xlabel('$\hat{R}$','Interpreter','latex');

% Format figure
figw = 17.2; % cm
subfigw = 0.4; % Fraction of figw
subfigh = 0.75; % Fraction of figh
padleft = 2/figw; % Fraction of figw
padbottom = 3/figw; % Fraction of figw
padbetween = .75/figw; % Fraction of figw
figh = 6;

set(subfig1,'Position',[padleft,padbottom,subfigw,subfigh])
set(subfig2,'Position',[padleft+(subfigw+1.2*padbetween),padbottom,subfigw,subfigh])

set(fig1,'PaperUnits','centimeters')
set(fig1,'PaperSize',[figw figh])
set(fig1,'PaperPosition',[0 0 figw figh])

print(fig1,'-dpdf','./Figures/figure_6.pdf');